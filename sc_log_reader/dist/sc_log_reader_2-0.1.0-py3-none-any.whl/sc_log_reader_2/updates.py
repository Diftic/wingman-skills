"""Single JSON downloads; explicit approval; transactional startup activation."""

from __future__ import annotations

import hashlib
import json
import os
import re
import tempfile
import time
from contextlib import contextmanager
from pathlib import Path
from urllib.parse import urlsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener

from .reader import MAX_PACKAGE_BYTES, InstructionError, Instructions, bundled_bytes


class UpdateError(ValueError):
    pass


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def validate_url(url):
    try:
        p = urlsplit(url)
        if (
            p.scheme != "https"
            or p.hostname != "raw.githubusercontent.com"
            or p.port not in (None, 443)
            or p.username
            or p.password
            or p.query
            or p.fragment
            or len(p.path.split("/")) < 5
            or not p.path.endswith(".json")
            or ".." in p.path.split("/")
        ):
            raise ValueError
    except ValueError as exc:
        raise UpdateError(
            "Use a raw.githubusercontent.com HTTPS JSON URL without credentials or query parameters"
        ) from exc
    return url


class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise UpdateError(
            "Update redirects are not accepted; configure the direct raw JSON URL"
        )


def fetch_json(url):
    validate_url(url)
    req = Request(
        url, headers={"Accept": "application/json", "User-Agent": "SC-Log-Reader-2/0.1"}
    )
    with build_opener(_NoRedirect).open(req, timeout=10) as response:
        size = response.headers.get("Content-Length")
        if size and int(size) > MAX_PACKAGE_BYTES:
            raise UpdateError("Update exceeds size limit")
        data = response.read(MAX_PACKAGE_BYTES + 1)
    if len(data) > MAX_PACKAGE_BYTES:
        raise UpdateError("Update exceeds size limit")
    return data


def atomic_write(path, raw):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, path)
    finally:
        if os.path.exists(name):
            os.unlink(name)


@contextmanager
def _lock(root):
    """OS lock releases on process exit; shared by host and approval CLI."""
    root.mkdir(parents=True, exist_ok=True)
    with (root / "update.lock").open("a+b") as stream:
        if stream.tell() == 0:
            stream.write(b"0")
            stream.flush()
        stream.seek(0)
        until = time.monotonic() + 2
        while True:
            try:
                if os.name == "nt":
                    import msvcrt

                    msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
                else:
                    import fcntl

                    fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except OSError as exc:
                if time.monotonic() > until:
                    raise UpdateError(
                        "Another instruction update is in progress"
                    ) from exc
                time.sleep(0.02)
        try:
            yield
        finally:
            stream.seek(0)
            if os.name == "nt":
                msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(stream.fileno(), fcntl.LOCK_UN)


class UpdateManager:
    def __init__(self, root, url=None, *, fetch=fetch_json):
        self.root = Path(root)
        self.url = validate_url(url) if url else None
        self.fetch = fetch
        self.running = None
        self.baseline = Instructions.load(bundled_bytes())
        self.base_digest = digest(self.baseline.raw)

    def _initial(self):
        return {
            "active": self.base_digest,
            "previous": None,
            "candidate": None,
            "staged": None,
            "highest_revision": self.baseline.revision,
            "revisions": {str(self.baseline.revision): self.base_digest},
        }

    def _manifest(self):
        p = self.root / "manifest.json"
        if not p.exists():
            return self._initial()
        try:
            if p.stat().st_size > 65536:
                raise ValueError
            value = json.loads(p.read_bytes())
            if not isinstance(value, dict) or not set(self._initial()) <= value.keys():
                raise ValueError
            for k in ("active", "previous", "candidate", "staged"):
                if value[k] is not None and not re.fullmatch(r"[a-f0-9]{64}", value[k]):
                    raise ValueError
            if type(value["highest_revision"]) is not int or not isinstance(
                value["revisions"], dict
            ):
                raise ValueError
            return value
        except (ValueError, TypeError, OSError):
            initial = self._initial()
            initial["error"] = "Invalid update manifest; using bundled definitions"
            return initial

    def _save(self, m):
        atomic_write(self.root / "manifest.json", json.dumps(m, indent=2).encode())

    def _read(self, key):
        if key == self.base_digest:
            return self.baseline
        if not isinstance(key, str) or not re.fullmatch(r"[a-f0-9]{64}", key):
            raise UpdateError("Invalid instruction digest")
        try:
            with (self.root / "objects" / (key + ".json")).open("rb") as stream:
                raw = stream.read(MAX_PACKAGE_BYTES + 1)
            if digest(raw) != key:
                raise UpdateError("Stored instruction digest mismatch")
            return Instructions.load(raw)
        except (OSError, InstructionError) as exc:
            raise UpdateError("Stored instructions are missing or invalid") from exc

    def status(self):
        with _lock(self.root):
            m = self._manifest()
            out = {
                "active_sha256": m["active"],
                "staged_sha256": m["staged"],
                "source_configured": bool(self.url),
            }
            try:
                out["active_version"] = self._read(m["active"]).version
                if m["candidate"]:
                    c = self._read(m["candidate"])
                    out.update(
                        candidate_version=c.version,
                        sha256=m["candidate"],
                        release_notes=c.data["release_notes"],
                    )
            except UpdateError as exc:
                out["error"] = str(exc)
            if "error" in m:
                out["error"] = m["error"]
            if self.running:
                out["running_version"] = self.running.version
            return out

    def startup(self):
        # Calling this again on a running service must never hot-apply a stage.
        if self.running is not None:
            return self.running
        with _lock(self.root):
            m = self._manifest()
            target = m["staged"] or m["active"]
            try:
                chosen = self._read(target)
                if m["staged"]:
                    previous = m["active"]
                    try:
                        self._read(previous)
                    except UpdateError:
                        previous = self.base_digest
                    m.update(previous=previous, active=target, staged=None)
                    m.pop("error", None)
            except UpdateError as exc:
                m["error"] = str(exc)
                chosen = None
                for fallback in (m["active"], m["previous"], self.base_digest):
                    try:
                        chosen = self._read(fallback)
                        m["active"] = fallback
                        break
                    except UpdateError:
                        continue
                m["staged"] = None
            self._save(m)
            self.running = chosen
            return chosen

    def check(self):
        if not self.url:
            return {"status": "not_configured"}
        try:
            raw = self.fetch(self.url)
            candidate = Instructions.load(raw)
        except (OSError, ValueError) as exc:
            raise UpdateError(
                "Could not fetch or validate instruction update: " + str(exc)
            ) from exc
        key = digest(raw)
        with _lock(self.root):
            m = self._manifest()
            known = m["revisions"].get(str(candidate.revision))
            if known and known != key:
                raise UpdateError("Published content changed without a new revision")
            active = self._read(m["active"])
            if (
                candidate.revision <= active.revision
                or candidate.revision < m["highest_revision"]
            ):
                return {"status": "up_to_date", "version": active.version}
            atomic_write(self.root / "objects" / (key + ".json"), raw)
            m.update(
                candidate=key,
                highest_revision=max(candidate.revision, m["highest_revision"]),
            )
            m["revisions"][str(candidate.revision)] = key
            # Retain bounded revision history; never lower the highest revision.
            m["revisions"] = dict(
                sorted(m["revisions"].items(), key=lambda x: int(x[0]))[-128:]
            )
            self._save(m)
        return {
            "status": "available",
            "version": candidate.version,
            "revision": candidate.revision,
            "sha256": key,
            "release_notes": candidate.data["release_notes"],
            "verified_game_builds": candidate.data["verified_game_builds"],
        }

    def approve(self, sha256):
        """Call only from a human-controlled CLI/UI, never an LLM tool."""
        with _lock(self.root):
            m = self._manifest()
            if not m["candidate"] or sha256 != m["candidate"]:
                raise UpdateError(
                    "Approval does not match the current reviewed candidate"
                )
            self._read(sha256)
            m["staged"] = sha256
            self._save(m)
        return {"status": "staged_for_next_startup", "sha256": sha256}

    def rollback(self):
        with _lock(self.root):
            m = self._manifest()
            target = m["previous"] or self.base_digest
            self._read(target)
            m["staged"] = target
            self._save(m)
        return {"status": "rollback_staged_for_next_startup", "sha256": target}
