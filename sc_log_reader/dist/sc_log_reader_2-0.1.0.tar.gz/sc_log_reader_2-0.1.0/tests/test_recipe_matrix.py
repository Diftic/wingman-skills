"""Hand-authored synthetic fixtures; these do not qualify a retail game build."""

import unittest

from sc_log_reader_2.reader import Instructions, Reader, bundled_bytes

NOTIFICATIONS = [
    ("armistice_zone", "Entering Armistice Zone"),
    ("bleeding", "Bleeding"),
    ("blueprint_received", "Received Blueprint: Citadel Core Base:"),
    (
        "channel_change",
        "You joined channel '@vehicle_NameAEGS_Avenger_Titan : Mallachi'",
    ),
    ("contract_accepted", "Contract Accepted: Delivery:"),
    ("contract_available", "Contract Available: Delivery:"),
    ("contract_complete", "Contract Complete: Delivery:"),
    ("contract_failed", "Contract Failed: Delivery:"),
    ("contract_shared", "Contract Shared: Delivery:"),
    ("crimestat_increased", "CrimeStat Rating Increased"),
    ("emergency_services", "Emergency Services Are En Route"),
    ("entered_monitored_space", "Entered Monitored Space"),
    ("exited_monitored_space", "Exited Monitored Space"),
    ("fined", "Fined 1,000 UEC"),
    ("fuel_low", "Low Fuel"),
    ("hangar_queue", "Joined hangar queue"),
    ("hangar_ready", "Hangar Request Completed"),
    ("incapacitated", "Incapacitated"),
    ("incoming_call", "Incoming call: Alice"),
    ("injury", "Minor Injury Detected - Left Arm - Tier 1"),
    ("journal_entry", "Journal Entry Added: A new entry:"),
    ("jurisdiction_change", "Entered Crusader Jurisdiction"),
    ("money_sent", "You sent Alice:\n1,500 aUEC:"),
    ("monitored_space_down", "Monitored Space Down"),
    ("monitored_space_restored", "Monitored Space Restored"),
    ("objective_complete", "Objective Complete: Deliver package:"),
    ("objective_new", "New Objective: Pick up package:"),
    ("objective_withdrawn", "Objective Withdrawn: Pick up package:"),
    ("party_invite", "Alice\nParty Invite Received"),
    ("party_left", "You have left the party."),
    ("party_member_joined", "Alice has joined the party."),
    ("qt_calibration_complete_group", "Quantum Travel Calibration Complete By Alice:"),
    ("quantum_calibration_complete", "Quantum Travel Calibration Complete:"),
    ("quantum_calibration_started", "Quantum Travel Calibration Started By Alice:"),
    ("refinery_complete", "Refinery Work Order complete at ARC-L1:"),
    ("restricted_area", "Leaving Restricted Area"),
    ("reward_earned", "Awarded 500 aUEC:"),
    ("transaction_complete", "Transaction Complete:"),
    ("vehicle_impounded", "Vehicle Impounded: Obstructing landing pad:"),
]
RECORDS = [
    (
        "attachment_received",
        "AttachmentReceived Status[persistent] Player[Mallachi] Port[weapon] Attachment[Medpen, pen, 123] Elapsed[0.5]",
    ),
    (
        "cargo_transfer",
        "FreightElevatorUIProvider::FillUnstowRequest FreightElevatorKiosk_Cargo[22] Entities: 2 Location: 33 RequestId: 1",
    ),
    (
        "commodity_buy",
        "CommodityUIProvider SendCommodityBuyRequest playerId[p] shopId[s] price[500] quantity[100 cSCU]",
    ),
    (
        "commodity_sell",
        "CommodityUIProvider SendCommoditySellRequest playerId[p] shopId[s] amount[500] quantity[1]",
    ),
    (
        "fatal_collision",
        "<FatalCollision> Fatal Collision occured for vehicle AEGS_Avenger_Titan PlayerPilot: 1 Zone: Stanton",
    ),
    (
        "insurance_claim",
        "CWallet::ProcessClaimToNextStep New Insurance Claim Request entitlementURN: urn:ship, requestId: 1",
    ),
    (
        "insurance_claim_complete",
        "CWallet::RmMulticastOnProcessClaimCallback entitlementURN: urn:ship, result: 0",
    ),
    (
        "inventory_location_update",
        "<Update Inventory Location> Player[Mallachi] Landing [0] -> [123] Location [0] -> [123]",
    ),
    ("join_pu", "<Join PU> shard[eu-1] address[server:1]"),
    (
        "location_change",
        "RequestLocationInventory Player[Mallachi] Location[RR_CRU_LEO]",
    ),
    (
        "med_bed_heal",
        "<MED BED HEAL> Perform surgery event Success leftArm: true rightLeg: false",
    ),
    (
        "personal_inventory_data",
        "RequestOrCreatePersonalInventoryData Player[Mallachi] inventoryID[1:Location:123]",
    ),
    (
        "qt_arrived",
        "AEGS_Avenger_Titan[123]|CSCItemNavigation::OnQuantumDriveArrived Quantum Drive has arrived at final destination",
    ),
    ("quantum_route_set", "Player Selected Quantum Target"),
    (
        "refinery_submitted",
        "MiningShopUIProvider::OnRefineryRequest playerId[p] shopId[s]",
    ),
    ("session_start", "AccountLoginCharacterStatus_Character name Mallachi geid 123"),
    (
        "shop_buy",
        "ShoppingProvider SendStandardItemBuyRequest playerId[p] client_price[265] quantity[1] currencyType[UEC]",
    ),
    (
        "shop_sell",
        "ShopUIProvider SendShopSellRequest playerId[p] client_price[265] quantity[1] currencyType[UEC]",
    ),
    (
        "shop_transaction_result",
        "ShoppingProvider RmShopFlowResponse playerId[p] result[Success]",
    ),
    ("user_login", "User Login Success Handle[Mallachi]"),
]


class RecipeTests(unittest.TestCase):
    def test_hand_authored_cases_are_recognized_and_extract_required_fields(self):
        reader = Reader(Instructions.load(bundled_bytes()))
        fixtures = RECORDS + [
            (
                kind,
                '<SHUDEvent> Added notification "'
                + text
                + '" [13] to queue. MissionId: [m1] ObjectiveId: [o1]',
            )
            for kind, text in NOTIFICATIONS
        ]
        for kind, text in fixtures:
            with self.subTest(event=kind):
                event = reader.parse("<2026-09-15T12:00:00Z> " + text)
                self.assertIsNotNone(event)
                self.assertEqual(event.event_type, kind)
                self.assertEqual(event.errors, [])


if __name__ == "__main__":
    unittest.main()
