# Legacy Wingman adapter — development only

`src/sc_log_reader_2/main.py` exports `SCLogReader2(Skill)` for the local legacy constructor `Skill(config, settings, wingman)`. `default_config.yaml` is its settings template.

This project has not modified or installed into Wingman. A maintainer would need to make this package and its `regex` dependency importable by the target Wingman runtime, register the skill using the template, and point it at a separate writable runtime directory. Do that in an isolated Wingman test installation first.

The constructor/prepare/unload/tools boundary is exercised with a host double; real Wingman import, UI registration, notification/TTS and shutdown are unverified. Public Wingman API 3 is not supported by this adapter yet.

Settings:

- **Star Citizen Path:** parent containing LIVE, PTU, etc.
- **Runtime Directory:** dedicated local database/update folder. Use this same path with CLI `check`, `status`, `approve` and `rollback`.
- **Instruction Update URL:** optional direct HTTPS raw GitHub JSON URL.
- **React to Game Events:** off by default. When enabled, batches up to 32 observations every four seconds, maximum ten batches until a real user message resets the allowance.

Automatic update checks run at startup and every six hours. An available update produces a toast; the user reviews version/release notes/digest with the CLI and approves the exact digest. There is no approval function in the model's tool list. An in-app review/install button is future UI work.

No donation/upload implementation is included. Do not register the old and new versions under the same module/name or let them share a runtime database.
