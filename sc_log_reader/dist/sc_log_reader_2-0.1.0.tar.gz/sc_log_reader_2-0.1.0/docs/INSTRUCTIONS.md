# Authoring and distributing instructions

## What a JSON update can change

Recognition patterns, notification labels, explicit bracket-field aliases, capture groups, normalization, lookup names and excluded cosmetic ports. Existing state event types are fixed in Python; inventing a new event or changing the meaning of a state transition requires an engine release.

The source of truth is `src/sc_log_reader_2/data/instructions.json`. It contains all recipes and lookups in a single file. No `git` executable or MCP server is required on a user's machine.

## Package contract

Required keys:

- `package_id`: `sc_log_reader_2`.
- `format_version` and `engine_version`: `1`.
- `revision`: positive monotonically increasing integer. Never change published bytes while reusing a revision.
- `version`, `release_notes`: user-facing labels; they do not establish compatibility.
- `verified_game_builds`: exact build strings established by replay/game qualification. Do not populate from a version label alone.
- `framing`: bounded record-start, timestamp and notification patterns. Timestamp and notification expressions each have one capture. Version 1 notification assembly expects double-quoted payloads.
- `ignore_records`, `lookups`, `rules`: recognition and extraction definitions.

Rules contain `id`, `event`, `match`, `read` and `required`. Unknown keys, operations, input sources, events, bad capture indexes, duplicate JSON keys and incompatible versions are rejected. Conditions support `all`, `any`, `not`, literal `contains` and `regex`.

Input sources are `record.text`, `notification.text` and already-extracted `fields.NAME`. All matching rules are considered: two matches are ambiguous, even if they have the same event type. Make alternatives disjoint or put them inside one rule.

## Supported read operations

| Operation | Behavior |
|---|---|
| `capture` | Extract declared numbered regex groups into fields |
| `bracket_fields` | Extract a named bracket field or explicit aliases; conflicting values invalidate the record |
| `constant` | Assign a bounded scalar JSON literal |
| `normalize` | `trim`, `lower`, `remove_commas`, `int`, `float`, or `regex_replace` |
| `choose` | First matching local extraction alternative |
| `collect_true_fields` | Extract explicitly true flags from a declared list |
| `exclude_values` | Ignore a known excluded value from a lookup table |
| `quantity_with_unit` | Extract a number only with an explicitly accepted unit |
| `notification_payload` | Extract the label's payload; remove one trailing legacy colon |

`regex_replace` uses **literal replacement text only** in version 1. Backslash replacement expressions such as `\1` or `\g<name>` are rejected. Use `capture` for group extraction. There is no arbitrary expression language, looping, code import or function lookup.

Example alias change (inside a `bracket_fields` operation):

```json
"fields": {
  "mission_id": ["MissionId", "MissionID"]
}
```

## Limits and errors

- Package: 512 KiB; record: 64 KiB; 128 rules; bounded condition and operation nesting.
- Regex: 2,048-character patterns, restricted repeat bounds/complexity, 10 ms per matching operation and a 100 ms reader deadline. Replacement output is bounded between normalization steps.
- Incomplete quoted notifications wait up to five seconds while monitoring. A new timestamped record flushes the previous incomplete notification as a diagnostic. They cannot book money or mutate game state.
- Missing required fields, conflicting aliases, conversion failures and timeouts produce local diagnostics. Missing source timestamps remain unknown; wall-clock observation time is stored separately.
- Tier 2 applies additional fixed requirements, so deleting a JSON `required` field does not authorize a state transition or money booking.

These limits constrain the interpreter. They do not prove that a syntactically valid recipe describes the game accurately.

## Update storage and recovery

Under the configured runtime directory:

```text
instructions/
  manifest.json
  update.lock
  objects/<SHA256>.json
events.sqlite3
```

The manifest references complete content-addressed files. Downloads validate before storage, and approval must name the currently reviewed digest. Manifest writes use a temporary file and atomic replacement; an OS lock coordinates the host with the approval command. Startup revalidates the staged digest and schema, keeps the prior file, and falls back to valid local definitions if a staged/active file is damaged. A corrupt manifest falls back to the bundle and reports an error.

The live engine is immutable for its lifetime. Checking, approving and querying status do not hot-reload it. Rollback is also staged for next startup. A definitions change clears short-lived trade/location/reward correlation windows; it does not replay historical transactions into the ledger again.

Publisher trust comes from the **configured HTTPS GitHub URL and repository control**. SHA-256 detects byte changes and binds approval; it is not a publisher signature. Redirects, credentials, non-HTTPS sources and URL query parameters are rejected. No logs are sent to GitHub; requests only fetch the instruction file. Signed releases could be added later if the deployment threat model requires them.

## Release procedure

1. Add a representative fixture and expected event/fields for the changed game output.
2. Make the JSON change, increment the revision and describe the change.
3. Run instruction validation, the full tests and replay against representative logs for the intended build. Inspect diagnostics and monetary effects.
4. Publish the complete file at the configured URL. This project does not publish automatically.
5. Users review, approve and restart. Retain the previous published file for comparison and recovery.
