# Architecture and behavior decisions

```text
Game.log (read-only)
  -> bounded byte/notification assembly
  -> JSON recognition + extraction (Tier 3)
  -> fixed evidence/state rules (Tier 2)
  -> atomic local journal + snapshot
  -> read-only tools and optional Wingman event batches (Tier 1)
```

## State and history

Every recognized input is identified by environment, file generation and byte range. Journal rows and the resulting state snapshot commit in the same SQLite transaction. A watcher checkpoint advances only after ingestion succeeds; retries start at the durable checkpoint and skip already-committed occurrences. Byte fragments, incomplete notifications and oversized-line discard state survive restart correctly.

The watcher separates LIVE/PTU/EPTU/HOTFIX/TECH-PREVIEW. A file replacement or detected truncation starts a new generation and clears prior state. File identity, a prefix hash and bytes around the checkpoint are used to detect rewrites. This is a bounded heuristic, not a complete file-content history. One monitoring service per runtime directory is the supported arrangement; the approval CLI may run alongside it.

History has no automatic deletion policy in this build. Runtime databases and downloaded definitions belong in a dedicated writable directory, never in the original skill's source directory.

## Observations and outcomes

- **Missions:** keyed by nonzero mission ID; accepted/completed/failed events require names. Objective changes affect a known mission. Availability/sharing does not mean acceptance.
- **Health:** recognized injuries normalize to six body parts. Healing clears only explicit true flags. A missing event never means recovery.
- **Location:** named inventory requests must match the known player. Nearby personal-inventory evidence establishes a location GUID; departure requires leaving that same nonzero GUID. Stale Landing fields cannot trigger departure. Temporal linking needs source timestamps.
- **Ships:** channel evidence establishes an aboard/model/owner observation. Exact model agreement alone remains `possible_player_ship`; it is excluded from proactive reactions. Unknown or mismatching model events do not become player events.
- **Trades:** a shop request needs a unique compatible response within 120 source-time seconds. Failure, missing identity or multiple candidates cannot book money. Currency must be explicit. Commodity requests have no proven completion route in this build, so remain requests.
- **Rewards:** explicit UEC/aUEC can become money; item quantities and unresolved bare numbers cannot. Repeated notification identity/time/content within the bounded session window is deduplicated. Nearby mission completion can be a possible association, not an asserted one. Reward components are not also booked as aggregate bundles.
- **Other movement/events:** remain observations or requests. An attachment is not automatically a purchase; an insurance callback code is not assumed to mean success.

The cash-flow ledger includes confirmed shop trades. General reward and transfer events remain available in event history. Inventory cost basis, reward-bundle UI and full old-skill parity are later work.

## Compatibility boundaries

The parsing recipes originated from the earlier assessment, then were transformed into the implemented version-1 language. The old design draft's prose/operator wishlist is not executable. The fixed engine implements the actual operations documented in INSTRUCTIONS.md.

All 59 mapped public event types have hand-authored synthetic recognition/extraction fixtures. That establishes coverage of the implemented recipes, not every possible branch of the old parser or current game output. Retail logs and actual Wingman lifecycle integration still require qualification.

The Wingman adapter targets the constructor and manual tool interface in the local checkout. Public API 3 is a separate integration target. Default proactive game reactions are off until the deployment is tested; update notices are separate from model prompts. The optional legacy process pipeline cannot enforce a host-wide no-tool policy; its event instruction is a prompt-level restriction, so live-host integration must verify that behavior before enabling reactions.
