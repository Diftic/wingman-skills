# SC Log Reader 2

**First runnable development build — 0.1.0.** An independent rewrite with one updateable JSON instruction file, a fixed state handler, and a thin Wingman interface.

The implementation is under `src/sc_log_reader_2`. The original Wingman project and the snapshot under `reference/` are separate. This project has not been installed into Wingman.

## What works now

- **Tier 3, reader:** 59 event recipes in `src/sc_log_reader_2/data/instructions.json`. Complete multiline notifications, explicit field aliases, UTC timestamps, conflicting-match detection and bounded regex execution. No downloaded Python, imports or evaluated expressions.
- **Tier 2, state:** missions, objectives, injuries, location transitions, ship observations, zones, sessions, trade confirmation and reward amounts. Missing units do not turn numbers into money. Requests and ambiguous confirmations stay distinct from completed transactions.
- **Tier 1, interface:** the five main read-only game/ledger tool names, plus update status; persistent local history; separate environments; incremental file monitoring; startup catch-up without old-event announcements. A prototype adapter targets the legacy API in your local Wingman checkout.
- **Updates:** fetch and validate one JSON file from a configured GitHub URL; show an update notice; require approval of its exact SHA-256; activate at the next service/Wingman startup. Keep previous and bundled definitions for recovery.
- **Development tools:** standalone log replay, instruction validation, update review/approval/rollback commands, and an isolated test suite.

## Run the standalone demo

From this directory, using the project's already-created environment:

```powershell
.\.venv\Scripts\python.exe -m sc_log_reader_2 replay examples\sample.log
.\.venv\Scripts\python.exe -m sc_log_reader_2 validate src\sc_log_reader_2\data\instructions.json
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

Replay reads the supplied log and uses a temporary database. It does not activate staged updates, write beside the log, run Wingman or upload logs. The bundled sample is synthetic.

To set up another development environment:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -e ".[dev]"
```

## Updating users with one JSON file

1. Change the runtime JSON, increment its integer `revision`, update `version` and `release_notes`, then validate and replay representative logs.
2. Publish that **one complete JSON file** to a GitHub repository you control.
3. Configure its direct `https://raw.githubusercontent.com/.../instructions.json` URL in the skill. The adapter checks at startup and every six hours. No publishing URL has been configured in this project.
4. Users receive an update notice. In this initial build, they review and approve through the commands below; an in-app review button remains to be integrated.
5. The running reader continues using its current instructions. The approved file activates at the next startup, after revalidation.

```powershell
# Replace the URL with your real publisher URL. Use the SAME runtime directory
# here and in the Wingman skill settings.
.\.venv\Scripts\python.exe -m sc_log_reader_2 check --state-dir .runtime --url "https://raw.githubusercontent.com/OWNER/REPOSITORY/main/instructions.json"
.\.venv\Scripts\python.exe -m sc_log_reader_2 status --state-dir .runtime
.\.venv\Scripts\python.exe -m sc_log_reader_2 approve --state-dir .runtime --digest EXACT_SHA256_FROM_CHECK

# Manual recovery: stages the previous version for the next startup.
.\.venv\Scripts\python.exe -m sc_log_reader_2 rollback --state-dir .runtime
```

Approval is not exposed as an AI tool. Automatic checks never approve or activate an update. See [instruction authoring and update behavior](docs/INSTRUCTIONS.md).

## Development limits

This is a working foundation, **not yet a drop-in replacement for the old skill**.

- Tests cover synthetic cases and patterns documented in the reference snapshot; no retail game build has been qualified. `verified_game_builds` is intentionally empty.
- The legacy Wingman adapter is tested against a host double. It has not been loaded in real Wingman. The public API 3 lifecycle needs a separate adapter/port before inclusion in a current upstream installer.
- The main read-only tool names are retained, but response formats and behavior have changed. The donor/upload UI, full per-event notification settings, injury reminders, reward-bundle presentation and inventory-cost/profit accounting are not ported. The ledger reports confirmed cash flow.
- Commodity and cargo request logs are retained as requests. This build does not claim an unproven confirmation path for them. A matching ship model is only a possible player-ship observation, not proof of ownership.
- A bad rule can still describe the wrong event. Structural validation cannot prove game semantics. User approval, replay checks and rollback remain necessary; there is no automatic rollback for every semantic error.
- Local history currently has no automatic retention policy. Unexpected in-place log rewrites that preserve file identity, length, prefix and checkpoint bytes can evade rotation detection.

See [architecture and implementation decisions](docs/ARCHITECTURE.md) and [Wingman integration status](integrations/wingman_legacy/README.md).

## Project layout

| Path | Purpose |
|---|---|
| `src/sc_log_reader_2/reader.py` | Fixed instruction validator/interpreter and record assembly |
| `src/sc_log_reader_2/data/instructions.json` | The single distributable parsing file |
| `src/sc_log_reader_2/state.py` | Fixed state and evidence rules |
| `src/sc_log_reader_2/service.py` | Local history, file monitoring and read-only tools |
| `src/sc_log_reader_2/updates.py` | Check, review, approval, startup activation and rollback |
| `src/sc_log_reader_2/main.py` | Legacy Wingman adapter |
| `tests/` | New isolated tests; never imports or runs the original skill |
| `docs/design/` | Frozen pre-implementation assessment and draft JSON |
| `reference/` | Frozen original skill snapshot and hashes |

The old `docs/design/reader-instructions.draft.json` remains a design document. The engine loads the new runtime JSON, not that draft.
